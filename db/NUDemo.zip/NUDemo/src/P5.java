
public class P5 {
public static void main(String[] args) throws InterruptedException {
	//abcdefghijkl
	long start=System.currentTimeMillis();
	Thread.sleep(10000);
	long end=System.currentTimeMillis();
	System.out.println("Time taken "+(end-start)+"ms");
	
}
}
